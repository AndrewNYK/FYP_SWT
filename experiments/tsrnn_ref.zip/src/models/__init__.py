import sys
sys.path.append('/csl/shifeng/rcGAN/')
print(sys.path)